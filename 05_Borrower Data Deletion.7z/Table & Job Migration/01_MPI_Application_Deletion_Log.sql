GO

/****** Object:  Table [dbo].[MPI_Application_Deletion_Log]    Script Date: 04-06-2024 11:45:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPI_Application_Deletion_Log]') AND type in (N'U'))
DROP TABLE [dbo].[MPI_Application_Deletion_Log]
GO

/****** Object:  Table [dbo].[MPI_Application_Deletion_Log]    Script Date: 04-06-2024 11:45:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MPI_Application_Deletion_Log](
	[OwnerID] [int] NOT NULL,
	[ApplicationId] [int] NOT NULL,
	[FirstName] [nvarchar](256) NULL,
	[MiddleName] [nvarchar](256) NULL,
	[LastName] [nvarchar](256) NULL,
	[StatusCodeId] [int] NULL,
	[Phone] [nvarchar](30) NULL,
	[Mobile] [nvarchar](30) NULL,
	[DOB] [datetime] NULL,
	[BorrowerTag] [nvarchar](256) NULL,
	[CreatedBy] [int] NULL,
	[CreatedOn] [datetime] NULL,
	[LastModifiedBy] [int] NULL,
	[LastModifiedOn] [datetime] NULL,
	[CreatedByType] [int] NULL,
	[ApplicationName] [nvarchar](2048) NULL,
	[RelatedToID] [int] NULL,
	[RelatedToName] [nvarchar](256) NULL,
	[RelatedToTypeID] [int] NULL
) ON [PRIMARY]
GO


